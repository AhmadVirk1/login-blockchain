export interface Auth {
	accessToken: string;
}
