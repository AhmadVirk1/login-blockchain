declare module 'react-blockies';
