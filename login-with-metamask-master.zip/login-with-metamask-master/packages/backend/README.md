# @login-with-metamask/backend

## Deploy Manually

You can use the docker image to deploy the backend, or use the command below to build and run the backend.

```bash
yarn build
yarn start
```
